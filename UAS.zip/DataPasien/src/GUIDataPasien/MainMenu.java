package GUIDataPasien;


public class MainMenu {

    
    public static void main(String[] args) {
        login lg = new login();
        lg.setVisible(true);
    
     
    }
    
}
