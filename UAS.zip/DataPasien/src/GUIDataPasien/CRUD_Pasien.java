package GUIDataPasien;

public interface CRUD_Pasien {
    abstract public boolean tambah_pasien(String a, String b,String c, String d, String e, String f, int g, String h, String i, int j);
    abstract public boolean edit_pasien(String a, String b,String c, String d, String e, String f, int g, String h, String i, int j);
    abstract public boolean hapus_pasien(String id);
    
}
