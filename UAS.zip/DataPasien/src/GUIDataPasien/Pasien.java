package GUIDataPasien;

import static GUIDataPasien.koneksi.connect;
import static GUIDataPasien.koneksi.stmt;
import javax.swing.JOptionPane;

public class Pasien extends koneksi implements CRUD_Pasien{

    public boolean tambah_pasien(String a, String b,String c, String d, String e, String f, int g, String h, String i, int j   ) {
                 try {
            String sql = "INSERT INTO data VALUES ('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"','"+f+"',"+g+",'"+h+"','"+i+"',"+j+")";
                     System.out.println(sql);
            stmt = connect().createStatement();
            stmt.execute(sql);
            JOptionPane.showMessageDialog(null,"Tambah Data Berhasil");
            
            
               return true;
        } catch (Exception x) {
            JOptionPane.showMessageDialog(null,"Tambah Data Gagal");
            return false;
        }
    }
    
    
    public boolean edit_pasien(String a, String b,String c, String d, String e, String f, int g, String h, String i, int j  ,String k ) {
                 try {
            String sql = "UPDATE data set Nama = '"+a+"',Kartu_Identitas = '"+b+"',Jenis_kelamin = '"+c+"',TTL = '"+d+"',Status = '"+e+"',Nama_wali = '"+f+"',No_Telp = "+g+",Dokter = '"+h+"',Jenis_rawat = '"+i+"',telp_wali = "+j+""
                    + " WHERE Nama = '"+k+"'";
                     System.out.println(sql);
            stmt = connect().createStatement();
            stmt.execute(sql);
            JOptionPane.showMessageDialog(null,"Edit Data Berhasil");
            
            
               return true;
        } catch (Exception x) {
            JOptionPane.showMessageDialog(null,"Edit Data Gagal");
            return false;
        }
    }
    
    
    
    
    @Override
    public boolean hapus_pasien(String nama) {
                 try {
            String sql = "DELETE FROM data WHERE Nama='"+nama+"'";
            stmt = connect().createStatement();
            stmt.execute(sql);
            JOptionPane.showMessageDialog(null,"Hapus Data Berhasil");
            
            
               return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Hapus Data Gagal");
            return false;
        }
    }

    boolean tambah_pasien(String nama) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean edit_pasien(String a, String b, String c, String d, String e, String f, int g, String h, String i, int j) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
