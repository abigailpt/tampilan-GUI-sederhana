package GUIDataPasien;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class koneksi {
    
    static Connection con;
    static Statement stmt;
    static final String DB_URL = "jdbc:mysql://localhost/datapasien";
    static String username = "root";
    static String password = "";

    public static Connection connect(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL,username,password);
            stmt = con.createStatement(); 
            System.out.println("Koneksi Berhasil");
        } catch (Exception e) {
            System.out.println("Koneksi Gagal");
        }
        return con;
    }
 
}
